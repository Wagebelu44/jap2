<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Monitor extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('monitor_model');	

	}
	public function index()
	{
// 		$data['cards'] = $this->home_model->get_gift_cards();
		$this->load->view('monitor');
	}
}